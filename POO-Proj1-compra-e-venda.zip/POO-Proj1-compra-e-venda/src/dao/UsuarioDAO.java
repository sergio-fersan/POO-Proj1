/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Model.Usuario;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Vini Trivellato
 */
public class UsuarioDAO {

    public void inserir(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, login, senha) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getLogin());
            stmt.setString(3, usuario.getSenha());
            stmt.executeUpdate();
        }
    }

    public Usuario autenticarUser(String login, String senha) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE Login = ?";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, login);

            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getString("nome"),
                        rs.getString("Login"),
                        rs.getString("senha"));
            }
        }
        return null;
    }

    public List<Usuario> listarUsuarios() throws SQLException {
        String sql = "SELECT * FROM usuarios";
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {

                Usuario usuario = new Usuario(
                        rs.getString("nome"),
                        rs.getString("Login"),
                        rs.getString("senha"));
                usuarios.add(usuario);
            }
        }
        return usuarios;
    }

    public void cadUsuario(Usuario cadUsuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, login, senha) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cadUsuario.getNome());
            stmt.setString(2, cadUsuario.getLogin());
            stmt.setString(3, cadUsuario.getSenha());

            stmt.executeUpdate();
            System.out.println("Usuário cadastrado com sucesso!");
        } catch (SQLException e) {

            System.err.println("Erro ao cadastrar o usuário: " + e.getMessage());
            throw e;

        }

    }
}
