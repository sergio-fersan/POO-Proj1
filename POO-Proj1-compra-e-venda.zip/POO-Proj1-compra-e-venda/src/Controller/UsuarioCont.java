/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Usuario;
import View.InformeSenha;
import View.Painel1;
import dao.UsuarioDAO;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.SQLException;


/**
 *
 * @author sergio
 */
public class UsuarioCont {
    private Painel1 view;
    private InformeSenha infSenha;
    private ArrayList<Usuario> usuarios;
    private UsuarioDAO usuarioDAO;
    Usuario falha = new Usuario("", "", ""); // obj pra caso falhe no login

    public UsuarioCont(Painel1 view) {
        this.view = view;
        this.usuarioDAO = new UsuarioDAO(); //banco
    }
    
    public UsuarioCont(InformeSenha infSenha){
        this.infSenha = infSenha;
        this.usuarioDAO = new UsuarioDAO();        //banco
    }
    
    public void cadUsuario(){
           String nome = view.getTxtNome().getText();
        String cpf = view.getTxtUsuario().getText();
        String senha = view.getTxtSenhaCad().getText();
        Usuario user = new Usuario( nome, cpf, senha);
        
        try {
            usuarioDAO.inserir(user);
            JOptionPane.showMessageDialog(view, "Usuario cadastrado com sucesso!!!!!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(view, "Erro ao cadastrar usuário: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    public Usuario logUsuario(){
        String cpf = view.getTxtLogin().getText();
        String senha = view.getTxtSenhaLog().getText();
        
        try {
            Usuario user = usuarioDAO.autenticarUser(cpf,senha);
            if (user != null && user.getSenha().equals(senha)) {
                return user;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(view, "Erro ao consultar usuário: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        return falha;
    }
    
    public boolean verifSenha(Usuario user){
        String senha = infSenha.getTxtSenha().getText();
        if (user.getSenha().equals(senha)) {
            JOptionPane.showMessageDialog(infSenha, "Senha correta!!!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            return true;
        } else {
            JOptionPane.showMessageDialog(infSenha, "Senha incorreta!! Tente novamente", "Aviso", JOptionPane.INFORMATION_MESSAGE);
            infSenha.getTxtSenha().setText("");
            return false;
        }
    }
 
    public void mostrar(){
         try {
            for (Usuario user : usuarioDAO.listarUsuarios()) {
                System.out.println(user);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(view, "Erro ao listar usuários: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}